# 内核实验

首先执行`make`来编译，然后打开三个终端，分别在各个终端依次运行：

```bash
# 启动追踪程序
make trace

# 执行RR调度程序
make runa

# 再执行一个任务
make runb
```
